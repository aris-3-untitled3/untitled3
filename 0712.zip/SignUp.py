## 회원가입

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import os

ui_file = os.path.join('/home/messi/ws_amr/qt/', "SignUp.ui")

from_class = uic.loadUiType(ui_file)[0]
#from_class = uic.loadUiType("Test.ui")[0]

class WindowClass(QMainWindow, from_class) :
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        
        self.tableWidget.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch)
        self.pushButton.clicked.connect(self.Add)

    def Add(self):
        row = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row)
        self.tableWidget.setItem(row, 0, QTableWidgetItem(self.editNum.text()))
       # self.tableWidget.setItem(row, 1, QTableWidgetItem(self.editGender.text()))
       # self.tableWidget.setItem(row, 2, QTableWidgetItem(self.dateEdit.date().toString("yyyy-MM-dd")))


if __name__ == "__main__":
    app = QApplication(sys.argv)

    myWindows = WindowClass()
    
    myWindows.show()
    
    sys.exit(app.exec_())