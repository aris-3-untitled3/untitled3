import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import os

# ui 파일 연결
ui_file = os.path.join('/home/messi/ws_amr/qt/', "Test.ui")
from_class = uic.loadUiType(ui_file)[0]
#from_class = uic.loadUiType("HelloQt.ui")[0]

# 화면 클래스
class WindowClass(QMainWindow, from_class) :
    def __init__(self):
        super().__init__()
        self.setupUi(self)  
        self.setWindowTitle("Test, PyQt!")
        
        #self.pushButton_1.clicked.connect(self.button1_Clicked)
        # self.pushButton_2.clicked.connect(self.button2_Clicked)
        # self.pushButton.clicked.connect(self.button3_Clicked)

        # self.pushButton_1.clicked.connect(self.radioButton.setChecked)

        # self.radioButton.clicked.connect(self.radio1_Clicked)
        # self.radioButton_2.clicked.connect(self.radio2_Clicked)
        # self.radioButton_3.clicked.connect(self.radio3_Clicked)

    # def radioClicked(self):
    #     if self.radioButton.isChecked():
    #         self.textEdit.setText("Radio 1")

    def button1_Clicked(self) :
        self.textEdit.setText("Button 1")
        self.radioButton.setChecked(True)

    def button2_Clicked(self) :
        self.textEdit.setText("Button 2")
        self.radioButton_2.setChecked(True)

    def button3_Clicked(self) :
        self.textEdit.setText("Button 3")
        self.radioButton_3.setChecked(True)

    

    def radio1_Clicked(self):
        self.textEdit.setText("Radio 1")

    def radio2_Clicked(self):
        self.textEdit.setText("Radio 2")

    def radio3_Clicked(self):
        self.textEdit.setText("Radio 3")

    def button1_Clicked(self) :
        self.textEdit.setText("Button 1")
    
    def button2_Clicked(self) :
        self.textEdit.setText("Button 2")

# Python Main 함수
if __name__ == "__main__":
    app = QApplication(sys.argv)    # 프로그램 실행

    myWindows = WindowClass()       # 화면 클래스 생성
    
    myWindows.show()                # 프로그램 화면 보이기
    
    sys.exit(app.exec_())           # 프로그램을 종료까지 동작시킴