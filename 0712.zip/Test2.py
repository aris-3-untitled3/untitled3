import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import os

ui_file = os.path.join('/home/messi/ws_amr/qt/', "Test2.ui")

from_class = uic.loadUiType(ui_file)[0]
#from_class = uic.loadUiType("Test.ui")[0]

class WindowClass(QMainWindow, from_class) :
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle("Test2")

        self.count = 0
        self.pushButton.clicked.connect(self.buttonClicked)
        self.label.setText(str(self.count))

    def buttonClicked(self):
        self.count += 1
        self.label.setText(str(self.count))

if __name__ == "__main__":
    app = QApplication(sys.argv)

    myWindows = WindowClass()
    
    myWindows.show()
    
    sys.exit(app.exec_())