# ## 회원가입


# class WindowClass(QMainWindow, from_class) :
#     def __init__(self):
#         super().__init__()
#         self.setupUi(self)
        
#         self.tableWidget.horizontalHeader().setSectionResizeMode(
#             QHeaderView.Stretch)
#         self.pushButton.clicked.connect(self.Add)



import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
from PyQt5 import QtGui
import os

ui_file = os.path.join('/home/messi/ws_amr/qt/', "Title.ui")

from_class = uic.loadUiType(ui_file)[0]

class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        
        # QLabel에 이미지 설정
        pixmap = QtGui.QPixmap("image.jpg")
        if pixmap.isNull():
            print("이미지를 로드할 수 없습니다.")
        else:
            self.label_pic.setPixmap(pixmap)
            self.label_pic.setScaledContents(True)  # QLabel 크기에 맞춰 이미지 크기 조정

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindows = WindowClass()
    myWindows.show()
    sys.exit(app.exec_())
