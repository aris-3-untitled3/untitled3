## 회원가입

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
from PyQt5 import QtGui
import os

ui_file = os.path.join('/home/messi/ws_amr/qt/', "Title.ui")

from_class = uic.loadUiType(ui_file)[0]
#from_class = uic.loadUiType("Test.ui")[0]

class WindowClass(QMainWindow, from_class) :
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        
        self.label_pic.setPixmap(QtGui.QPixmap("image.jpg"))


if __name__ == "__main__":
    app = QApplication(sys.argv)

    myWindows = WindowClass()
    
    myWindows.show()
    
    sys.exit(app.exec_())