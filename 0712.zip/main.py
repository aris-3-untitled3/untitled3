# main.py
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import uic
import Language  # Language.ui에서 변환된 Python 파일
import Recommend_kor  # Recommend.ui에서 변환된 Python 파일

class LanguageWindow(QMainWindow, Language.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.open_recommend_window)
        self.pushButton_2.clicked.connect(self.open_recommend_window)
    
    def open_recommend_window(self):
        self.recommend_window = RecommendWindow()
        self.recommend_window.show()
        self.close()

class RecommendWindow(QMainWindow, Recommend_kor.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    language_window = LanguageWindow()
    language_window.show()
    sys.exit(app.exec_())
