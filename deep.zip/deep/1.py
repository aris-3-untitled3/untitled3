from deepface import DeepFace
import os
import cv2
import shutil
import sqlite3

# 기존 데이터베이스 경로
db_path = "/home/addinedu/07.26/deep"

# SQLite 데이터베이스 파일 경로
sqlite_db = os.path.join(db_path, 'coupons.db')

# 데이터베이스 초기화 함수
def initialize_db():
    conn = sqlite3.connect(sqlite_db)
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        coupons INTEGER DEFAULT 0
    )
    ''')
    conn.commit()
    conn.close()

# 데이터베이스 경로가 존재하는지 확인하는 함수
def ensure_db_path_exists(db_path):
    if not os.path.exists(db_path):
        os.makedirs(db_path)
        print(f"데이터베이스 경로가 생성되었습니다: {db_path}")
    else:
        print(f"데이터베이스 경로가 이미 존재합니다: {db_path}")

# 얼굴 인식을 사용하여 데이터베이스에서 고객을 찾는 함수
def find_customer(img_path, model_name='ArcFace', detector_backend='retinaface'):
    try:
        df_list = DeepFace.find(img_path=img_path, db_path=db_path, model_name=model_name, detector_backend=detector_backend, enforce_detection=True)
        if df_list and not df_list[0].empty:
            customer_name = df_list[0].iloc[0]['identity'].split('/')[-2]  # 고객 이름 추출
            return customer_name
        return None
    except ValueError as e:
        print(e)
        return None

# 새로운 고객을 등록하는 함수
def register_new_customer(img_path, customer_name):
    def clean_name(name):
        return ''.join(e for e in name if e.isalnum() or e.isdigit())

    customer_name_clean = clean_name(customer_name)
    customer_dir = os.path.join(db_path, customer_name_clean)
    os.makedirs(customer_dir, exist_ok=True)
    new_img_path = os.path.join(customer_dir, f"{customer_name_clean}.jpg")
    shutil.copy(img_path, new_img_path)

    conn = sqlite3.connect(sqlite_db)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO customers (name, coupons) VALUES (?, ?)', (customer_name, 0))
    conn.commit()
    conn.close()

    print(f"새로운 고객이 등록되었습니다: {customer_name}")

# 고객에게 쿠폰을 발급하는 함수
def issue_coupon(customer_name):
    conn = sqlite3.connect(sqlite_db)
    cursor = conn.cursor()
    cursor.execute('SELECT coupons FROM customers WHERE name = ?', (customer_name,))
    row = cursor.fetchone()
    if row:
        new_coupons = row[0] + 1
        cursor.execute('UPDATE customers SET coupons = ? WHERE name = ?', (new_coupons, customer_name))
        conn.commit()
        print(f"{customer_name}님에게 쿠폰이 발급되었습니다! 현재 쿠폰 개수: {new_coupons}")
    else:
        print(f"고객 {customer_name}을(를) 찾을 수 없습니다.")
    conn.close()

# 고객의 쿠폰 개수를 확인하는 함수
def check_coupon_count(customer_name):
    conn = sqlite3.connect(sqlite_db)
    cursor = conn.cursor()
    cursor.execute('SELECT coupons FROM customers WHERE name = ?', (customer_name,))
    row = cursor.fetchone()
    if row:
        print(f"{customer_name}님의 현재 쿠폰 개수: {row[0]}")
    else:
        print(f"고객 {customer_name}을(를) 찾을 수 없습니다.")
    conn.close()

# 이미지 전처리 함수
def preprocess_image(img_path):
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    equalized = cv2.equalizeHist(gray)
    cv2.imwrite(img_path, equalized)
    return equalized

# 메인 함수
if __name__ == "__main__":
    # 데이터베이스 경로가 존재하는지 확인
    ensure_db_path_exists(db_path)

    # SQLite 데이터베이스 초기화
    initialize_db()

    # 웹캠을 사용하여 이미지 캡처
    cap = cv2.VideoCapture(0)

    # 카메라 설정 조정
    cap.set(cv2.CAP_PROP_BRIGHTNESS, 0.6)  # 밝기 조정
    cap.set(cv2.CAP_PROP_CONTRAST, 0.6)    # 대비 조정
    cap.set(cv2.CAP_PROP_EXPOSURE, -4)     # 노출 조정

    while True:
        ret, frame = cap.read()
        if ret:
            img_path = "temp.jpg"
            cv2.imwrite(img_path, frame)
            print(f"이미지가 {img_path}에 저장되었습니다.")

            # 이미지 전처리
            preprocess_image(img_path)

            # 고객이 이미 존재하는지 확인
            found_customer = find_customer(img_path)
            if found_customer:
                print(f"{found_customer}님 어서오세요!")
                action = input(f"쿠폰을 적립하시겠습니까? (yes/no/check): ").strip().lower()
                if action == "yes":
                    issue_coupon(found_customer)
                elif action == "check":
                    check_coupon_count(found_customer)
                else:
                    print("쿠폰 적립을 건너뜁니다.")
            else:
                # 고객 이름 입력
                customer_name = input("손님 이름을 입력하세요: ").strip()

                # 고객 이름이 제공되지 않은 경우 처리
                if not customer_name:
                    print("손님 이름이 제공되지 않았습니다.")
                    continue

                register_new_customer(img_path, customer_name)
                print(f"{customer_name}님 어서오세요!")
                action = input(f"쿠폰을 적립하시겠습니까? (yes/no): ").strip().lower()
                if action == "yes":
                    issue_coupon(customer_name)
                else:
                    print("쿠폰 적립을 건너뜁니다.")
        else:
            print("이미지 캡처에 실패했습니다.")
            break

    cap.release()
    cv2.destroyAllWindows()
