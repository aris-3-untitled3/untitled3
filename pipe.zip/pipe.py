import cv2
import mediapipe as mp
import math

class HandPoseApp:
    def __init__(self):
        # 웹캠으로부터 영상을 받아오는 객체 초기화
        self.cap = cv2.VideoCapture(0)

        # Mediapipe 손 인식을 위한 객체 초기화
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(min_detection_confidence=0.6, min_tracking_confidence=0.6, max_num_hands=2)

        # Mediapipe 포즈 인식을 위한 객체 초기화
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(min_detection_confidence=0.6, min_tracking_confidence=0.6)

        # 랜드마크를 그리기 위한 drawing utils 초기화
        self.mp_drawing = mp.solutions.drawing_utils

    # 세 점을 이용해 각도를 계산하는 함수
    def calculate_angle(self, a, b, c):
        angle = math.degrees(math.atan2(c.y - b.y, c.x - b.x) - math.atan2(a.y - b.y, a.x - b.x))
        angle = abs(angle)
        if angle > 180:
            angle = 360 - angle
        return angle

    # 손가락이 곧게 펴져 있는지를 판단하는 함수
    def is_finger_properly_straight(self, finger_tip, finger_pip, finger_mcp):
        angle_pip = self.calculate_angle(finger_mcp, finger_pip, finger_tip)
        return 160 <= angle_pip <= 180

    # 두 점 사이의 거리를 계산하는 함수
    def distance(self, a, b):
        return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2)

    # OK 제스처를 인식하는 함수
    def is_ok_gesture(self, hand_landmarks):
        thumb_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.THUMB_TIP]
        index_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.INDEX_FINGER_TIP]

        # 엄지와 검지 끝 사이의 거리 계산
        thumb_index_distance = self.distance(thumb_tip, index_tip)

        # 손 크기를 기준으로 엄지와 검지 사이의 거리 정규화
        wrist = hand_landmarks.landmark[self.mp_hands.HandLandmark.WRIST]
        middle_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_TIP]
        hand_size = self.distance(wrist, middle_tip)
        
        normalized_distance = thumb_index_distance / hand_size

        # 나머지 손가락들이 곧게 펴져 있는지 확인
        middle_straight = self.is_finger_properly_straight(
            hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_TIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_PIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_MCP]
        )
        ring_straight = self.is_finger_properly_straight(
            hand_landmarks.landmark[self.mp_hands.HandLandmark.RING_FINGER_TIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.RING_FINGER_PIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.RING_FINGER_MCP]
        )
        pinky_straight = self.is_finger_properly_straight(
            hand_landmarks.landmark[self.mp_hands.HandLandmark.PINKY_TIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.PINKY_PIP],
            hand_landmarks.landmark[self.mp_hands.HandLandmark.PINKY_MCP]
        )

        # OK 제스처 조건을 모두 만족하는지 반환
        return (
            normalized_distance < 0.2 and
            middle_straight and ring_straight and pinky_straight
        )

    # 화면에 텍스트를 표시하는 함수
    def draw_text(self, frame, text, position=(50, 50), color=(0, 255, 255)):
        cv2.putText(frame, text, position, cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)

    # 손 랜드마크를 처리하는 함수
    def process_hand_landmarks(self, frame, hand_landmarks, hand_label):
        # 손 랜드마크를 이미지에 그림
        self.mp_drawing.draw_landmarks(frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)

        # OK 제스처를 인식하면 화면에 텍스트 출력
        if self.is_ok_gesture(hand_landmarks):
            self.draw_text(frame, f'{hand_label} OK Gesture Detected', color=(0, 255, 0))

    # 메인 루프를 실행하는 함수
    def run(self):
        while self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                break

            # 이미지를 RGB로 변환 (Mediapipe는 RGB 이미지를 사용)
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            hand_results = self.hands.process(image)
            pose_results = self.pose.process(image)

            # 손이 인식되었을 때
            if hand_results.multi_hand_landmarks:
                for hand_landmarks, hand_handedness in zip(hand_results.multi_hand_landmarks, hand_results.multi_handedness):
                    hand_label = hand_handedness.classification[0].label
                    self.process_hand_landmarks(frame, hand_landmarks, hand_label)
            else:
                self.draw_text(frame, 'No Hand Detected', color=(0, 0, 255))

            # 결과 이미지를 윈도우에 표시
            cv2.imshow('Mediapipe Hands & Pose', frame)

            # 'q' 키를 누르면 루프 종료
            if cv2.waitKey(10) & 0xFF == ord('q'):
                break

        # 캡처 객체와 윈도우 해제
        self.cap.release()
        cv2.destroyAllWindows()

# 프로그램의 진입점
def main():
    app = HandPoseApp()
    app.run()

if __name__ == '__main__':
    main()
