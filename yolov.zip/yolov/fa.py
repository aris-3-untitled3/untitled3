import cv2
from ultralytics import YOLO

# YOLOv8n-obb 모델 파일의 경로 지정
model_path = '/home/addinedu/1234/08.22/yolo/obb/obbbest.pt'

# 모델 로드
try:
    model = YOLO(model_path)
except Exception as e:
    print(f"모델을 로드하는 중 에러 발생: {e}")
    exit()

# 웹캠 캡처 초기화 (노트북 내장 웹캠 사용)
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("웹캠을 열 수 없습니다.")
    exit()

# 프레임 해상도 설정
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# 모델의 클래스 이름 리스트 (라벨링 시 사용한 클래스 이름들과 동일해야 함)
class_names = model.names  # 모델에서 클래스 이름을 자동으로 가져옴

while True:
    ret, img = cap.read()  # 웹캠에서 프레임 읽기
    if not ret:
        print("웹캠에서 프레임을 읽을 수 없습니다.")
        break  # 프레임 읽기 실패 시 루프 종료

    # YOLOv8n-obb 모델로 객체 감지
    results = model(img)

    # 디버깅: results 전체 내용 출력
    print("Full Results object:", results)

    # 감지된 객체가 있는지 확인
    if results:
        print("Results available, processing...")

        if results[0].obb is not None:
            annotated_frame = results[0].orig_img  # 원본 이미지로 초기화
            print("OBB data detected.")

            # 감지된 객체의 OBB 좌표를 사용
            for idx, obb in enumerate(results[0].obb.xyxyxyxy):
                # OBB의 네 개의 꼭짓점 좌표 가져오기
                print("Processing OBB data:", obb)
                points = obb.squeeze().cpu().numpy()  # 텐서를 numpy 배열로 변환

                # 디버깅: OBB 좌표 출력
                print("OBB points:", points)

                # 각 점에 원 그리기
                for point in points:
                    point = tuple(map(int, point))  # 좌표를 정수로 변환
                    cv2.circle(annotated_frame, point, 5, (0, 255, 0), -1)  # 초록색 점 그리기

                # 클래스 ID에 맞는 이름을 가져와서 표시
                class_id = results[0].obb.cls[idx]  # 감지된 객체의 클래스 ID 가져오기
                class_name = class_names[int(class_id)]  # 클래스 ID를 이름으로 변환
                print(f"Detected object class name: {class_name}")

                # 물품 이름을 좌표 위에 추가
                cv2.putText(annotated_frame, class_name, 
                            (int(points[0][0]), int(points[0][1]) - 20), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2, cv2.LINE_AA)

                # 좌표 텍스트 추가
                for i, point in enumerate(points):
                    point = tuple(map(int, point))  # 좌표를 정수로 변환
                    cv2.putText(annotated_frame, f"({point[0]}, {point[1]})", 
                                (point[0] + 10, point[1] - 10), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1, cv2.LINE_AA)
        else:
            print("No OBB data found.")
    else:
        print("No objects detected in results.")
        # 객체가 감지되지 않은 경우 원본 프레임을 사용
        annotated_frame = img

    # 반시계 방향으로 프레임 회전
    rotated_frame = cv2.rotate(annotated_frame, cv2.ROTATE_90_COUNTERCLOCKWISE)

    # 원본 프레임 및 주석이 달린(회전된) 이미지 표시
    cv2.imshow('Original Frame', img)  # 원본 프레임 표시
    cv2.imshow('Rotated Frame', rotated_frame)  # 회전된 프레임 표시

    if cv2.waitKey(1) == ord('q'):  # 'q' 키를 누르면 루프 종료
        break

cap.release()  # 웹캠 자원 해제
cv2.destroyAllWindows()  # 모든 OpenCV 창 닫기
